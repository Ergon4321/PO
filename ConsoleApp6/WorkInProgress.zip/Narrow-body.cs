﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Narrow_body : Plane
    {
        private int seats;
        private int range;
        private int id;

        public Narrow_body(int seats, int range, int id)
        {
            this.seats = seats;
            this.range = range;
            this.id = id;
        }
    }
}
