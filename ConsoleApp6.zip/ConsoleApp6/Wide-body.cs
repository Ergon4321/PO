﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Wide_body : Plane
    {
        private int seats = 60;
        private int range = 15000;

        public Wide_body() { }
    }
}
