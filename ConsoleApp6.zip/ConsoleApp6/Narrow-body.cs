﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Narrow_body : Plane
    {
        private int seats = 30;
        private int range = 50000;

        public Narrow_body()
        {
        
        }
    }
}
